const express = require("express");
const Admin = require("../models/admin.js");
const User = require("../models/user");
const auth = require("../middleware/adminAuth");
const multer = require("multer");
const router = express.Router();

const upload = multer ({
    limits : {
        fileSize: 1000000
    },
    fileFilter (req,file ,cb){
        if(!file.originalname.match(/\.(jpg|jpeg|png)$/)) {
            return cb(new Error("Please upload a image"))
        }
        cb(undefined,true)
}
})






router.post("/admin/signup", async (req, res) => {
  // console.log(req.body)
  try {
    const admin = new Admin(req.body);
    await admin.save();
    // console.log({admin})
    const token = await admin.generateAuthToken();
    res.status(201).send({ admin, token });
  } catch (e) {
    res.status(400).send(e);
  }
});
router.get("/admin/me", auth, async (req, res) => {
  res.send(req.admin);
});
router.post("/admin/login", async (req, res) => {
  try {
    const { username, password } = req.body;
    const admin = await Admin.findByCredentials(username, password);
    const token = await admin.generateAuthToken();
    res.status(201).send({ admin, token });
  } catch (e) {
    res.status(405).send(e);
  }
});
router.patch("/admin/update", auth, async (req, res) => {
  try {
    const updates = Object.keys(req.body);
    const allowedUpdates = ["username", "password"];
    const isValidOperation = updates.every((update) => {
      return allowedUpdates.includes(update);
    });
    if (!isValidOperation)
      return res.status(408).send({ error: "Invalid update" });
    updates.forEach((update) => {
      req.admin[update] = req.body[update];
    });
    await req.admin.save();
    res.send(req.admin);
  } catch (e) {
    res.status(406).send(e);
  }
});

router.delete("/admin/delete", auth, async (req, res) => {
  try {
    await Admin.deleteOne({ _id: req.admin._id });
    res.send(req.admin);
  } catch (e) {
    res.status(400).send(e);
  }
});

router.post("/admin/logout", auth, async (req, res) => {
  try {
    req.admin.tokens = [];
    await admin.save();
    res.status(202).send();
  } catch (e) {
    res.status(409).send(e);
  }
});

//Admin CRUD
router.get("/admin/getUsers", auth, async (req, res) => {
  try {
    const users = await User.find({});
    res.status(210).send(users);
  } catch (e) {
    res.status(500).send(e.message);
  }
});

router.get("/admin/getUser/:id", auth, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) throw new Error("User not found");
    res.status(211).send(user);
  } catch (e) {
    res.status(409).send(e);
  }
});

router.patch(
  "/admin/updateUser/:id",
  upload.single("avatar"),
  auth,
  async (req, res) => {
    try {
      console.log(req.body);
      const updates = Object.keys(req.body);
      console.log(updates);
      const allowedUpdates = ["name", "email", "password", "avatar"];
      let isValidOperation = updates.every((update) =>
        allowedUpdates.includes(update)
      );
      const user = await User.findById(req.params.id);
      if (!isValidOperation)
        return res.status(408).send({ error: "Invalid update" });
      updates.forEach((update) => (user[update] = req.body[update]));
      if (req.file) {
        user.avatar = req.file.buffer;
      }
      await user.save();
      res.status(201).send(user);
    } catch (e) {
      res.status(400).send(e.message);
    }
  }
);

router.delete("/admin/deleteUser/:id", auth, async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) throw new Error("User Not Found");
    res.status(213).send(user);
  } catch (e) {
    res.status(410).send(e);
  }
});

module.exports = router;
