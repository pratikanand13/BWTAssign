const express = require('express')
const User = require('../models/user')
const auth = require('../middleware/userAuth')
const multer  = require('multer')
const sharp = require('sharp') // to use high processing images 

const router = new express.Router()

const upload = multer ({
    limits : {
        fileSize: 1000000
    },
    fileFilter (req,file ,cb){
        if(!file.originalname.match(/\.(jpg|jpeg|png)$/)) {
            return cb(new Error("Please upload a image"))
        }
        cb(undefined,true)
}
})

router.post('/user/signup', upload.single('avatar'), async (req, res) => {
   
    // console.log({req})
    try {
      if (req.file) {
        // If a file is provided, process it (assuming it's an image)
        const buffer = await sharp(req.file.buffer).resize({ width: 250, height: 250 }).png().toBuffer();
        req.body.avatar = buffer; // Save the processed image buffer in the user model
      }
  
      const user = new User(req.body)
      
      await user.save();
      const token = await user.generateAuthToken();
      
      res.status(201).send({ user, token });
    } catch (e) {
      
      res.status(400).send({ error: e.message });
    }
  })
router.get("/user/me",auth, async (req, res) => {
    
    res.send(req.user)
  })

router.post('/user/login' , async(req,res) => {
    try{
       
        const { email, phoneNumber, password } = req.body
        const user = await User.findByCredentials(email || phoneNumber, password);
        const token = await user.generateAuthToken()
        res.send({user,token})
    } catch(e) {
        console.log(e)
        res.status(401).send()
    }

})

router.patch('/user/update',auth,upload.single('avatar'),async(req,res)=>{
    const updates = Object.keys(req.body)
    const allowedUpdates = ['name','avatar']
    const isValidOperation = updates.every((update)=>{
        return allowedUpdates.includes(update)
    }) 
    if(!isValidOperation) return res.status(408).send({ error: "Invalid update" })
    try{
        updates.forEach((update)=>{
            req.user[update] = req.body[update]
        })
        if(req.file){
            req.user.avatar = req.file.buffer
        }

        await req.user.save()
        res.send(req.user)
} catch (e){
    res.status(422).send(e)
}
}) 

router.delete('/user/delete',auth,async(req,res)=>{
    try{
        // console.log(req.user)
        await User.deleteOne({_id:req.user._id})
        res.send(req.user)
    } catch(e) { 
        res.status(401).send()
    }
})

router.post('/users/logout',auth,async(req,res)=>{
    try{
        req.user.tokens = req.user.tokens.filter((token) => {
          return token.token !== req.token //filter function craetes a array containg tokens except the auth one
        })
        await req.user.save();
        res.send()
    }catch (e) {
      res.status(500).send()
    }
})

router.post('/users/logoutAll',auth, async(req,res)=>{
    try{  
      // console.log(req.user)
      req.user.tokens = []
      await req.user.save()
      res.status(200).send()
  
    }
    catch(e){
      res.send(500).send()
    }
  
  })

module.exports = router