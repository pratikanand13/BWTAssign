const express = require('express')
const app = express()
const port = process.env.PORT || 3000
const jwt = require('jsonwebtoken')


const userRouter = require('./routers/user')
const adminRouter  = require('./routers/admin')


require('./db/mongoose') 
const User = require('./models/user.js')
const Admin = require('./models/admin.js')







app.use(express.json())
app.use(userRouter)
app.use(adminRouter)


app.listen(port, () => {
    console.log(`Server is running on ${port}`);
  });